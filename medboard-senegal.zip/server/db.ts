import { eq, and, desc, asc, sql, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, hospitals, services, serviceMembers, patients, patientTasks, alerts, serviceMessages, activityLog, releves, consultations, clinicalNotes, vitalSigns, observations } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ===== HOSPITALS =====
export async function getHospitals() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(hospitals).orderBy(asc(hospitals.name));
}

// ===== SERVICES =====
export async function getServicesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const memberships = await db.select().from(serviceMembers).where(eq(serviceMembers.userId, userId));
  if (memberships.length === 0) return [];
  const serviceIds = memberships.map(m => m.serviceId);
  const result = await db.select().from(services).where(sql`${services.id} IN (${sql.join(serviceIds.map(id => sql`${id}`), sql`, `)})`);
  return result;
}

export async function getServiceById(serviceId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(services).where(eq(services.id, serviceId)).limit(1);
  return result[0];
}

export async function createService(data: { name: string; specialty: string; hospitalId: number; createdById: number; totalBeds?: number; description?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(services).values(data).$returningId();
  // Auto-add creator as member
  await db.insert(serviceMembers).values({ serviceId: result.id, userId: data.createdById, role: "chef" });
  return result.id;
}

// ===== PATIENTS =====
export async function getPatientsByService(serviceId: number, filter?: string) {
  const db = await getDb();
  if (!db) return [];
  let conditions = [eq(patients.serviceId, serviceId)];
  
  if (filter === "urgents") {
    conditions.push(eq(patients.status, "critique"));
  } else if (filter === "sortie_prevue") {
    conditions.push(sql`${patients.expectedDischarge} IS NOT NULL AND ${patients.actualDischarge} IS NULL`);
  } else if (filter === "sortis") {
    conditions.push(sql`${patients.actualDischarge} IS NOT NULL`);
  } else {
    // "tous" - exclude discharged
    conditions.push(sql`${patients.actualDischarge} IS NULL`);
  }
  
  return db.select().from(patients).where(and(...conditions)).orderBy(desc(patients.createdAt));
}

export async function getPatientById(patientId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(patients).where(eq(patients.id, patientId)).limit(1);
  return result[0];
}

export async function createPatient(data: {
  firstName: string; lastName: string; serviceId: number; createdById: number;
  bedNumber?: number; status?: "stable" | "modere" | "critique";
  diagnosis?: string; allergies?: string; antecedents?: string; notes?: string;
  dateOfBirth?: string; gender?: "M" | "F"; phone?: string; emergencyContact?: string;
  expectedDischarge?: Date;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(patients).values(data).$returningId();
  return result.id;
}

export async function updatePatient(patientId: number, data: Partial<{
  firstName: string; lastName: string; bedNumber: number | null; status: "stable" | "modere" | "critique";
  diagnosis: string; allergies: string; antecedents: string; notes: string;
  expectedDischarge: Date | null; actualDischarge: Date | null; dpsCompleted: boolean;
}>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(patients).set(data).where(eq(patients.id, patientId));
}

// ===== TASKS =====
export async function getTasksByPatient(patientId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(patientTasks).where(eq(patientTasks.patientId, patientId)).orderBy(desc(patientTasks.createdAt));
}

export async function getTasksByService(serviceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(patientTasks).where(eq(patientTasks.serviceId, serviceId)).orderBy(desc(patientTasks.createdAt));
}

export async function createTask(data: { patientId: number; serviceId: number; title: string; description?: string; priority?: "low" | "medium" | "high" | "urgent"; dueDate?: Date; assignedToId?: number; createdById: number }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(patientTasks).values(data).$returningId();
  return result.id;
}

export async function updateTask(taskId: number, data: Partial<{ status: "pending" | "in_progress" | "completed" | "overdue"; completedAt: Date | null }>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(patientTasks).set(data).where(eq(patientTasks.id, taskId));
}

// ===== ALERTS =====
export async function getAlertsByService(serviceId: number, onlyActive?: boolean) {
  const db = await getDb();
  if (!db) return [];
  let conditions = [eq(alerts.serviceId, serviceId)];
  if (onlyActive) conditions.push(eq(alerts.resolved, false));
  return db.select().from(alerts).where(and(...conditions)).orderBy(desc(alerts.createdAt));
}

export async function createAlert(data: { serviceId: number; patientId?: number; type: "dps_missing" | "no_bed" | "task_overdue" | "critical_patient"; message: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(alerts).values(data).$returningId();
  return result.id;
}

export async function resolveAlert(alertId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(alerts).set({ resolved: true, resolvedAt: new Date(), resolvedById: userId }).where(eq(alerts.id, alertId));
}

// ===== MESSAGES =====
export async function getMessagesByService(serviceId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: serviceMessages.id,
    content: serviceMessages.content,
    createdAt: serviceMessages.createdAt,
    userId: serviceMessages.userId,
    userName: users.name,
  }).from(serviceMessages)
    .leftJoin(users, eq(serviceMessages.userId, users.id))
    .where(eq(serviceMessages.serviceId, serviceId))
    .orderBy(desc(serviceMessages.createdAt))
    .limit(limit);
}

export async function createMessage(data: { serviceId: number; userId: number; content: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(serviceMessages).values(data).$returningId();
  return result.id;
}

// ===== ACTIVITY LOG =====
export async function getActivityByService(serviceId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: activityLog.id,
    action: activityLog.action,
    details: activityLog.details,
    createdAt: activityLog.createdAt,
    patientId: activityLog.patientId,
    userName: users.name,
  }).from(activityLog)
    .leftJoin(users, eq(activityLog.userId, users.id))
    .where(eq(activityLog.serviceId, serviceId))
    .orderBy(desc(activityLog.createdAt))
    .limit(limit);
}

export async function logActivity(data: { serviceId: number; patientId?: number; userId: number; action: string; details?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(activityLog).values(data);
}

// ===== RELEVES =====
export async function getRelevesByService(serviceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(releves).where(eq(releves.serviceId, serviceId)).orderBy(desc(releves.createdAt)).limit(20);
}

export async function createReleve(data: { serviceId: number; generatedById: number; content: string; pdfUrl?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(releves).values(data).$returningId();
  return result.id;
}

// ===== SERVICE MEMBERS =====
export async function getServiceMembers(serviceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: serviceMembers.id,
    userId: serviceMembers.userId,
    role: serviceMembers.role,
    joinedAt: serviceMembers.joinedAt,
    userName: users.name,
    medicalRole: users.medicalRole,
  }).from(serviceMembers)
    .leftJoin(users, eq(serviceMembers.userId, users.id))
    .where(eq(serviceMembers.serviceId, serviceId));
}

export async function addServiceMember(serviceId: number, userId: number, role?: "chef" | "senior" | "junior" | "stagiaire") {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(serviceMembers).values({ serviceId, userId, role: role || "junior" });
}

// ===== USER PROFILE =====
export async function updateUserProfile(userId: number, data: { medicalRole?: "externe" | "interne" | "resident" | "medecin"; hospitalId?: number; name?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(users).set(data).where(eq(users.id, userId));
}

// ===== CONSULTATIONS =====
export async function getConsultationsByService(serviceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(consultations).where(eq(consultations.serviceId, serviceId)).orderBy(desc(consultations.consultDate));
}

export async function createConsultation(data: { serviceId: number; patientFirstName: string; patientLastName: string; motif: string; createdById: number; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(consultations).values(data).$returningId();
  return result.id;
}

export async function updateConsultationStatus(id: number, status: "en_attente" | "vu" | "reporte") {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(consultations).set({ status }).where(eq(consultations.id, id));
}

// ===== CLINICAL NOTES =====
export async function getNotesByPatient(patientId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: clinicalNotes.id,
    type: clinicalNotes.type,
    content: clinicalNotes.content,
    createdAt: clinicalNotes.createdAt,
    createdById: clinicalNotes.createdById,
    userName: users.name,
  }).from(clinicalNotes)
    .leftJoin(users, eq(clinicalNotes.createdById, users.id))
    .where(eq(clinicalNotes.patientId, patientId))
    .orderBy(desc(clinicalNotes.createdAt));
}

export async function createClinicalNote(data: { patientId: number; serviceId: number; type: "dar" | "soap" | "libre"; content: string; createdById: number }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(clinicalNotes).values(data).$returningId();
  return result.id;
}

// ===== VITAL SIGNS =====
export async function getVitalsByPatient(patientId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(vitalSigns).where(eq(vitalSigns.patientId, patientId)).orderBy(desc(vitalSigns.recordedAt));
}

export async function createVitalSigns(data: { patientId: number; serviceId: number; recordedById: number; temperature?: string; bloodPressure?: string; heartRate?: string; respiratoryRate?: string; oxygenSaturation?: string; gcs?: string; pain?: string; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(vitalSigns).values(data).$returningId();
  return result.id;
}

// ===== OBSERVATIONS =====
export async function getObservationsByPatient(patientId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: observations.id,
    content: observations.content,
    category: observations.category,
    createdAt: observations.createdAt,
    createdById: observations.createdById,
    userName: users.name,
  }).from(observations)
    .leftJoin(users, eq(observations.createdById, users.id))
    .where(eq(observations.patientId, patientId))
    .orderBy(desc(observations.createdAt));
}

export async function createObservation(data: { patientId: number; serviceId: number; content: string; category?: "clinique" | "infirmier" | "evolution" | "autre"; createdById: number }) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const [result] = await db.insert(observations).values(data).$returningId();
  return result.id;
}
