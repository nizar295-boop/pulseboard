import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  medicalRole: mysqlEnum("medicalRole", ["externe", "interne", "resident", "medecin"]).default("interne"),
  hospitalId: int("hospitalId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Hospitals - Établissements de santé sénégalais
 */
export const hospitals = mysqlTable("hospitals", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  city: varchar("city", { length: 100 }).notNull().default("Dakar"),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Medical services (departments)
 */
export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  specialty: varchar("specialty", { length: 100 }).notNull(),
  hospitalId: int("hospitalId").notNull(),
  createdById: int("createdById").notNull(),
  totalBeds: int("totalBeds").default(20),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Service members - users assigned to services
 */
export const serviceMembers = mysqlTable("service_members", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("memberRole", ["chef", "senior", "junior", "stagiaire"]).default("junior"),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
});

/**
 * Patients
 */
export const patients = mysqlTable("patients", {
  id: int("id").autoincrement().primaryKey(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  dateOfBirth: varchar("dateOfBirth", { length: 10 }),
  gender: mysqlEnum("gender", ["M", "F"]).default("M"),
  phone: varchar("phone", { length: 50 }),
  emergencyContact: varchar("emergencyContact", { length: 255 }),
  serviceId: int("serviceId").notNull(),
  bedNumber: int("bedNumber"),
  status: mysqlEnum("status", ["stable", "modere", "critique"]).default("stable").notNull(),
  admissionDate: timestamp("admissionDate").defaultNow().notNull(),
  expectedDischarge: timestamp("expectedDischarge"),
  actualDischarge: timestamp("actualDischarge"),
  diagnosis: text("diagnosis"),
  allergies: text("allergies"),
  antecedents: text("antecedents"),
  notes: text("notes"),
  dpsCompleted: boolean("dpsCompleted").default(false),
  createdById: int("createdById").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Patient tasks
 */
export const patientTasks = mysqlTable("patient_tasks", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  serviceId: int("serviceId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium"),
  status: mysqlEnum("taskStatus", ["pending", "in_progress", "completed", "overdue"]).default("pending"),
  dueDate: timestamp("dueDate"),
  assignedToId: int("assignedToId"),
  completedAt: timestamp("completedAt"),
  createdById: int("createdById").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Alerts
 */
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  patientId: int("patientId"),
  type: mysqlEnum("alertType", ["dps_missing", "no_bed", "task_overdue", "critical_patient"]).notNull(),
  message: text("message").notNull(),
  resolved: boolean("resolved").default(false),
  resolvedAt: timestamp("resolvedAt"),
  resolvedById: int("resolvedById"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Service messages (team chat)
 */
export const serviceMessages = mysqlTable("service_messages", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  userId: int("userId").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Activity timeline
 */
export const activityLog = mysqlTable("activity_log", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  patientId: int("patientId"),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Releve (shift handover reports)
 */
export const releves = mysqlTable("releves", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  generatedById: int("generatedById").notNull(),
  content: text("content").notNull(),
  pdfUrl: text("pdfUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Consultations - pour les hôpitaux qui font des consultations externes
 */
export const consultations = mysqlTable("consultations", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  patientFirstName: varchar("patientFirstName", { length: 100 }).notNull(),
  patientLastName: varchar("patientLastName", { length: 100 }).notNull(),
  motif: varchar("motif", { length: 255 }).notNull(),
  status: mysqlEnum("consultStatus", ["en_attente", "vu", "reporte"]).default("en_attente").notNull(),
  notes: text("notes"),
  createdById: int("createdById").notNull(),
  consultDate: timestamp("consultDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Clinical notes (DAR / SOAP format)
 */
export const clinicalNotes = mysqlTable("clinical_notes", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  serviceId: int("serviceId").notNull(),
  type: mysqlEnum("noteType", ["dar", "soap", "libre"]).default("dar").notNull(),
  content: text("content").notNull(),
  createdById: int("createdById").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Vital signs
 */
export const vitalSigns = mysqlTable("vital_signs", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  serviceId: int("serviceId").notNull(),
  temperature: varchar("temperature", { length: 10 }),
  bloodPressure: varchar("bloodPressure", { length: 20 }),
  heartRate: varchar("heartRate", { length: 10 }),
  respiratoryRate: varchar("respiratoryRate", { length: 10 }),
  oxygenSaturation: varchar("oxygenSaturation", { length: 10 }),
  gcs: varchar("gcs", { length: 10 }),
  pain: varchar("pain", { length: 10 }),
  notes: text("notes"),
  recordedById: int("recordedById").notNull(),
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
});

/**
 * Observations
 */
export const observations = mysqlTable("observations", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  serviceId: int("serviceId").notNull(),
  content: text("content").notNull(),
  category: mysqlEnum("obsCategory", ["clinique", "infirmier", "evolution", "autre"]).default("clinique"),
  createdById: int("createdById").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
