import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { Activity, Shield, Clock, Users, Bed, AlertTriangle, MessageSquare, FileText, ChevronRight, Heart, Building2, Stethoscope } from "lucide-react";

const hospitals = [
  { name: "Hôpital Fann", city: "Dakar" },
  { name: "Hôpital Principal", city: "Dakar" },
  { name: "Hôpital Abass Ndao", city: "Dakar" },
];

const roles = [
  { title: "Externe", description: "Observez, apprenez et contribuez à la prise en charge des patients.", icon: "🎓" },
  { title: "Interne", description: "Gérez vos patients au quotidien avec un outil pensé pour vous.", icon: "🩺" },
  { title: "Résident", description: "Supervisez votre service et assurez la continuité des soins.", icon: "📋" },
  { title: "Médecin", description: "Pilotez votre équipe et gardez une vue d'ensemble sur vos services.", icon: "👨‍⚕️" },
];

const features = [
  { title: "Tableau de bord intelligent", description: "Vue d'ensemble de vos services, alertes actives et statistiques clés en un coup d'œil.", icon: Activity },
  { title: "Gestion des lits", description: "Chaque patient, sa place, son état. Visualisez l'occupation en temps réel.", icon: Bed },
  { title: "Alertes automatiques", description: "DPS manquante, patient sans lit, tâches en retard — rien ne vous échappe.", icon: AlertTriangle },
  { title: "Relève simplifiée", description: "Générée automatiquement, groupée par priorité. Export PDF et copie WhatsApp.", icon: FileText },
  { title: "Messagerie d'équipe", description: "Communication sécurisée et centralisée au sein de chaque service.", icon: MessageSquare },
  { title: "Sécurité des données", description: "Vos données patients sont protégées et accessibles uniquement à votre équipe.", icon: Shield },
];

const stats = [
  { value: "60%", label: "des erreurs médicales surviennent lors d'une mauvaise relève" },
  { value: "45min", label: "de transmission orale économisées par garde" },
  { value: "10s", label: "pour transmettre une relève complète" },
];

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Heart className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-lg tracking-tight">MedBoard</span>
            <span className="text-xs text-muted-foreground font-medium px-2 py-0.5 bg-muted rounded-full">Sénégal</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground transition-colors">Fonctionnalités</a>
            <a href="#hospitals" className="hover:text-foreground transition-colors">Établissements</a>
            <a href="#roles" className="hover:text-foreground transition-colors">Pour qui</a>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <Button onClick={() => navigate("/dashboard")} size="sm">
                Tableau de bord <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            ) : (
              <>
                <Button variant="ghost" size="sm" asChild>
                  <a href={getLoginUrl("/dashboard")}>Se connecter</a>
                </Button>
                <Button size="sm" asChild>
                  <a href={getLoginUrl("/dashboard")}>Commencer <ChevronRight className="w-4 h-4 ml-1" /></a>
                </Button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
        <div className="container relative">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8 animate-fade-in">
              <Building2 className="w-4 h-4" />
              Utilisé dans les hôpitaux sénégalais
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1] mb-6 animate-slide-up">
              Votre service,{" "}
              <span className="text-primary">enfin organisé.</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-10 animate-slide-up" style={{ animationDelay: "100ms" }}>
              Vous gérez 30 patients. Vous n'avez pas dormi depuis 20h.
              La relève commence dans 10 minutes.
              MedBoard s'en souvient pour vous.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: "200ms" }}>
              <Button size="lg" className="text-base px-8 h-12" asChild>
                <a href={getLoginUrl("/dashboard")}>
                  Essayer gratuitement <ChevronRight className="w-5 h-5 ml-2" />
                </a>
              </Button>
              <Button variant="outline" size="lg" className="text-base px-8 h-12" asChild>
                <a href="#features">Découvrir les fonctionnalités</a>
              </Button>
            </div>
            <div className="flex items-center justify-center gap-6 mt-8 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Gratuit pour commencer</span>
              <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> 2 minutes pour démarrer</span>
              <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Aucune formation requise</span>
            </div>
          </div>
        </div>
      </section>

      {/* Hospitals */}
      <section id="hospitals" className="py-16 border-y border-border/50 bg-muted/30">
        <div className="container">
          <p className="text-center text-xs font-semibold tracking-widest text-muted-foreground uppercase mb-8">
            Adopté au sein des établissements de référence
          </p>
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16">
            {hospitals.map((h) => (
              <div key={h.name} className="flex items-center gap-3 text-muted-foreground hover:text-foreground transition-colors">
                <Building2 className="w-5 h-5 text-primary/70" />
                <span className="font-medium text-sm">{h.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center p-8 rounded-2xl bg-card border border-border/50 shadow-sm">
                <div className="text-4xl font-bold text-primary mb-3">{stat.value}</div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 bg-muted/20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Tout ce dont vous avez besoin</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Un outil qui pense comme vous — et qui vous libère pour soigner.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <div key={i} className="group p-6 rounded-2xl bg-card border border-border/50 shadow-sm hover:shadow-md hover:border-primary/20 transition-all duration-300">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Roles */}
      <section id="roles" className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Pour chaque profil médical</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Que vous soyez externe, interne, résident ou médecin, MedBoard s'adapte à votre rôle.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {roles.map((role, i) => (
              <div key={i} className="p-6 rounded-2xl bg-card border border-border/50 shadow-sm text-center hover:shadow-md hover:-translate-y-1 transition-all duration-300">
                <div className="text-4xl mb-4">{role.icon}</div>
                <h3 className="font-semibold mb-2">{role.title}</h3>
                <p className="text-sm text-muted-foreground">{role.description}</p>
                <Button variant="ghost" size="sm" className="mt-4 text-primary" asChild>
                  <a href={getLoginUrl("/dashboard")}>
                    Commencer <ChevronRight className="w-4 h-4 ml-1" />
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary/5">
        <div className="container text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Prêt à organiser votre service ?</h2>
          <p className="text-muted-foreground max-w-md mx-auto mb-8">
            Rejoignez les équipes soignantes qui utilisent MedBoard pour améliorer la prise en charge de leurs patients.
          </p>
          <Button size="lg" className="text-base px-8 h-12" asChild>
            <a href={getLoginUrl("/dashboard")}>
              Commencer gratuitement <ChevronRight className="w-5 h-5 ml-2" />
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border/50">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
                <Heart className="w-3 h-3 text-primary-foreground" />
              </div>
              <span className="font-semibold text-sm">MedBoard Sénégal</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2026 MedBoard. Conçu pour les équipes soignantes sénégalaises.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
